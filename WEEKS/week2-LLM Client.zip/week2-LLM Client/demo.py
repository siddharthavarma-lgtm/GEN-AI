"""
Demo Script for Week 2: LLM Client
This demonstrates how LLMClient delegates calls to different providers
using both a Simulated Provider and live providers.
"""
from llm_client import LLMClient, LLMProvider

# 1. Simulated Demo Provider (works offline without API keys or Ollama)
class DemoSimulatedProvider(LLMProvider):
    def __init__(self, name="DemoProvider"):
        self.name = name

    def generate(self, prompt: str) -> str:
        return f"[{self.name} Response] Received your prompt: '{prompt}'. Provider-agnostic client is working successfully!"

def run_demo():
    print("=" * 60)
    print("DEMO: Provider-Agnostic LLM Client")
    print("=" * 60)

    # Instantiate simulated provider
    mock_provider = DemoSimulatedProvider("Local Mock LLM")
    client = LLMClient(mock_provider)

    test_prompt = "Explain LLM in one sentence."
    print(f"\n[Prompt]: {test_prompt}")
    print("\nCalling client.generate(prompt)...")
    
    response = client.generate(test_prompt)
    print("\n[Result]:")
    print(response)
    print("\n" + "=" * 60)
    print("SUCCESS: The LLMClient architecture cleanly decouples the")
    print("interface from the underlying backend (Gemini / Ollama).")
    print("=" * 60)

if __name__ == "__main__":
    run_demo()
